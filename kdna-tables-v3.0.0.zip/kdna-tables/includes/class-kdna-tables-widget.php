<?php
/**
 * KDNA Table Elementor widget.
 *
 * Session 1 scope: registers the widget, hosts the Type Chooser at the top
 * of the Content tab, exposes a Change Table Type link at the bottom, and
 * dispatches render output to a placeholder template until later sessions
 * fill in the General and Comparison modes.
 *
 * @package KDNA_Tables
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KDNA_Tables_Widget extends \Elementor\Widget_Base {

	/**
	 * Selector for the first-column body cells of a general table.
	 *
	 * Carries one class more than the Body Cells odd/even row selectors
	 * ({{WRAPPER}} .kdna-table--general tbody .kdna-table__row--odd >
	 * .kdna-table__cell) so First Column background and colour win the
	 * cascade against them rather than losing on specificity.
	 */
	const FIRST_COL_SELECTOR = '{{WRAPPER}} .kdna-table--general tbody .kdna-table__row > .kdna-table__cell.kdna-table__cell--first-col';

	public function get_name() {
		return 'kdna-table';
	}

	public function get_title() {
		return esc_html__( 'KDNA Table', 'kdna-tables' );
	}

	public function get_icon() {
		return 'eicon-table';
	}

	public function get_categories() {
		return array( KDNA_Tables_Plugin::CATEGORY_SLUG );
	}

	public function get_keywords() {
		return array( 'table', 'comparison', 'data', 'pricing', 'kdna' );
	}

	/*
	 * Style dependencies.
	 *
	 * Recent Elementor builds route both get_settings_for_display() and
	 * Controls_Stack::get_data('settings') through
	 * sanitize_settings(array $settings): array, which fatals when the
	 * stored settings for a given instance happen to be null (very common
	 * for unmigrated v1.x instances and for newly-spawned widgets in the
	 * editor preview). We catch the TypeError and fall back to enqueuing
	 * every handle, matching the v1.x defensive behaviour. The
	 * conditional-asset optimisation still applies to every healthy v2.0
	 * instance, which is the common path.
	 */
	public function get_style_depends() {
		$all = array(
			KDNA_Tables_Plugin::FRONTEND_STYLE_HANDLE,
			KDNA_Tables_Plugin::COMPARISON_STYLE_HANDLE,
			KDNA_Tables_Plugin::RESPONSIVE_STYLE_HANDLE,
		);

		try {
			$settings = $this->get_settings_for_display();
		} catch ( \Throwable $e ) {
			return $all;
		}

		if ( ! is_array( $settings ) ) {
			return $all;
		}

		$deps     = array( KDNA_Tables_Plugin::FRONTEND_STYLE_HANDLE );
		$table_id = isset( $settings['selected_table_id'] ) ? (int) $settings['selected_table_id'] : 0;
		if ( $table_id > 0 && class_exists( 'KDNA_Tables_CPT' ) ) {
			$type = KDNA_Tables_CPT::get_type( $table_id );
			if ( 'comparison' === $type ) {
				$deps[] = KDNA_Tables_Plugin::COMPARISON_STYLE_HANDLE;
			}
		}

		$responsive_mode = isset( $settings['responsive_mode'] ) ? (string) $settings['responsive_mode'] : '';
		if ( '' !== $responsive_mode && 'none' !== $responsive_mode ) {
			$deps[] = KDNA_Tables_Plugin::RESPONSIVE_STYLE_HANDLE;
		}

		return $deps;
	}

	/*
	 * Frontend JS handles the tooltip touch / keyboard interaction and
	 * the column picker. It always loads when the widget is present so
	 * tooltips remain accessible even when no responsive mode is set.
	 */
	public function get_script_depends() {
		return array( KDNA_Tables_Plugin::FRONTEND_SCRIPT_HANDLE );
	}

	/*
	 * Under the e_optimized_markup experiment Elementor drops the
	 * .elementor-widget-container inner wrapper. The widget output is then
	 * a single .kdna-table__wrapper div, and no CSS should target the
	 * legacy container class.
	 */
	public function has_widget_inner_wrapper(): bool {
		if (
			class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance->experiments )
			&& \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' )
		) {
			return false;
		}
		return true;
	}

	protected function register_controls() {
		$this->register_source_table_controls();
		$this->register_general_style_controls();
		$this->register_comparison_content_controls();
		$this->register_comparison_style_controls();
		$this->register_responsive_content_controls();
		$this->register_responsive_style_controls();
		$this->register_sticky_content_controls();
		$this->register_sticky_style_controls();
	}

	/*
	 * Source Table section. The only Content controls that own data are now
	 * the Select Table dropdown and a hidden mirror of the picked table's
	 * type. The hidden type drives all the type-conditioned Style sections,
	 * with the editor JS updating it on dropdown change via AJAX.
	 */
	protected function register_source_table_controls() {
		$this->start_controls_section(
			'section_source',
			array(
				'label' => esc_html__( 'Source Table', 'kdna-tables' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'selected_table_id',
			array(
				'label'        => esc_html__( 'Table', 'kdna-tables' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'options'      => $this->get_table_options(),
				'default'      => '',
				'label_block'  => true,
				'description'  => esc_html__( 'Pick a table from your library. Edit a table once, every widget instance using it updates.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'selected_table_manage_link',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'<a href="%1$s" target="_blank" rel="noopener" class="kdna-tables-manage-link">%2$s</a>',
					esc_url( admin_url( 'edit.php?post_type=kdna_table' ) ),
					esc_html__( 'Manage tables', 'kdna-tables' )
				),
				'content_classes' => 'elementor-descriptor',
			)
		);

		/*
		 * Hidden mirror of the selected table's type. Editor JS keeps it in
		 * sync with selected_table_id via AJAX so the type-conditioned Style
		 * sections re-evaluate as soon as a different table is picked.
		 */
		$this->add_control(
			'selected_table_type',
			array(
				'type'    => \Elementor\Controls_Manager::HIDDEN,
				'default' => '',
			)
		);

		// Mirror of the picked table's item count (0-6). The editor JS
		// updates this via AJAX so the per-column style controls can hide
		// slots that the picked table does not have.
		$this->add_control(
			'selected_table_item_count',
			array(
				'type'    => \Elementor\Controls_Manager::HIDDEN,
				'default' => '0',
			)
		);

		$this->end_controls_section();
	}

	private function get_table_options() {
		$options = array( '' => esc_html__( 'Select a table', 'kdna-tables' ) );

		if ( ! post_type_exists( 'kdna_table' ) ) {
			return $options;
		}

		$tables = get_posts(
			array(
				'post_type'      => 'kdna_table',
				'post_status'    => 'publish',
				'numberposts'    => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'fields'         => 'ids',
				'suppress_filters' => true,
			)
		);

		foreach ( $tables as $id ) {
			$title = get_the_title( $id );
			if ( '' === trim( $title ) ) {
				/* translators: %d: post id */
				$title = sprintf( esc_html__( 'Table #%d', 'kdna-tables' ), $id );
			}
			$options[ (string) $id ] = $title;
		}

		return $options;
	}

	protected function register_sticky_content_controls() {
		$this->start_controls_section(
			'section_sticky',
			array(
				'label'     => esc_html__( 'Sticky First Column', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => array( 'selected_table_id!' => '' ),
			)
		);

		$this->add_control(
			'sticky_first_column',
			array(
				'label'        => esc_html__( 'Sticky First Column', 'kdna-tables' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'kdna-tables' ),
				'label_off'    => esc_html__( 'Off', 'kdna-tables' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => esc_html__( 'Keeps the first column visible as the table scrolls horizontally on desktop. Responsive modes take precedence at their breakpoint.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();
	}

	protected function register_sticky_style_controls() {
		$this->start_controls_section(
			'section_sticky_style',
			array(
				'label'     => esc_html__( 'Sticky Column', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array(
					'selected_table_id!'  => '',
					'sticky_first_column' => 'yes',
				),
			)
		);

		$this->add_control(
			'sticky_bg',
			array(
				'label'       => esc_html__( 'Background', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::COLOR,
				'selectors'   => array(
					'{{WRAPPER}}' => '--kdna-sticky-bg: {{VALUE}};',
				),
				'description' => esc_html__( 'Solid background sits behind the sticky column while the rest of the table scrolls under it.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'sticky_shadow_color',
			array(
				'label'     => esc_html__( 'Right Edge Shadow Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-sticky-shadow-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'sticky_shadow_size',
			array(
				'label'      => esc_html__( 'Right Edge Shadow Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 40, 'step' => 1 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 8,
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-sticky-shadow-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'sticky_z_index',
			array(
				'label'     => esc_html__( 'Z-Index', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100,
				'step'      => 1,
				'default'   => 2,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-sticky-z-index: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}


	/**
	 * Register a Style/Width/Colour trio for one set of rule lines.
	 *
	 * Each trio writes to CSS variables rather than to border properties
	 * directly, so kdna-tables.css owns which edge of which cell the line
	 * lands on and the controls only ever say what it looks like. That is
	 * what keeps the general table free of an outer frame: no control can
	 * put a border on a cell that has no neighbour.
	 *
	 * Style defaults to '' so nothing is written and the stylesheet
	 * default applies — which for the header vertical lines and the first
	 * column's right edge means inheriting the Body Cells vertical line
	 * through a var() fallback chain. Width and Colour are deliberately
	 * default-less for the same reason. Choosing None writes
	 * border-style: none and the line disappears.
	 *
	 * Note that Elementor emits CSS for a control even while `condition`
	 * hides it, so Width and Colour keep emitting when Style is None.
	 * That is harmless: border-style: none wins regardless of width.
	 *
	 * @param string $prefix        Control name prefix.
	 * @param string $var_prefix    CSS variable prefix, without the -style
	 *                              / -width / -color suffix.
	 * @param string $default_label Label for the "leave it alone" option.
	 * @param string $description   Description shown under the Style control.
	 */
	private function register_line_controls( $prefix, $var_prefix, $default_label, $description = '' ) {
		$this->add_control(
			$prefix . '_style',
			array(
				'label'       => esc_html__( 'Style', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array(
					''       => $default_label,
					'solid'  => esc_html__( 'Solid', 'kdna-tables' ),
					'dashed' => esc_html__( 'Dashed', 'kdna-tables' ),
					'dotted' => esc_html__( 'Dotted', 'kdna-tables' ),
					'double' => esc_html__( 'Double', 'kdna-tables' ),
					'none'   => esc_html__( 'None (hidden)', 'kdna-tables' ),
				),
				'selectors'   => array(
					'{{WRAPPER}}' => $var_prefix . '-style: {{VALUE}};',
				),
				'description' => $description,
			)
		);

		$this->add_responsive_control(
			$prefix . '_width',
			array(
				'label'      => esc_html__( 'Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 20, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => $var_prefix . '-width: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					$prefix . '_style!' => 'none',
				),
			)
		);

		$this->add_control(
			$prefix . '_color',
			array(
				'label'     => esc_html__( 'Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => $var_prefix . '-color: {{VALUE}};',
				),
				'condition' => array(
					$prefix . '_style!' => 'none',
				),
			)
		);
	}

	protected function register_general_style_controls() {
		$general_condition = array( 'selected_table_type' => 'general' );

		// ─── Section: Table Wrapper ───────────────────────────────────────
		$this->start_controls_section(
			'section_general_style_wrapper',
			array(
				'label'     => esc_html__( 'Table Wrapper', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $general_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'wrapper_background',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-table__wrapper--general',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'wrapper_border',
				'selector' => '{{WRAPPER}} .kdna-table__wrapper--general',
			)
		);

		$this->add_responsive_control(
			'wrapper_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-table-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'wrapper_box_shadow',
				'selector' => '{{WRAPPER}} .kdna-table__wrapper--general',
			)
		);

		$this->add_responsive_control(
			'wrapper_max_width',
			array(
				'label'      => esc_html__( 'Max Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 100, 'max' => 1600, 'step' => 1 ),
					'%'  => array( 'min' => 1, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table__wrapper--general' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'wrapper_alignment',
			array(
				'label'                => esc_html__( 'Alignment', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::CHOOSE,
				'options'              => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'              => 'center',
				'selectors_dictionary' => array(
					'left'   => 'margin-right: auto; margin-left: 0;',
					'center' => 'margin-left: auto; margin-right: auto;',
					'right'  => 'margin-left: auto; margin-right: 0;',
				),
				'selectors'            => array(
					'{{WRAPPER}} .kdna-table__wrapper--general' => '{{VALUE}}',
				),
				'condition'            => array(
					'wrapper_max_width[size]!' => '',
				),
			)
		);

		$this->add_responsive_control(
			'wrapper_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table__wrapper--general' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'caption_heading',
			array(
				'label'     => esc_html__( 'Caption', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'caption_typography',
				'selector' => '{{WRAPPER}} .kdna-table--general .kdna-table__caption',
			)
		);

		$this->add_control(
			'caption_color',
			array(
				'label'     => esc_html__( 'Caption Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__caption' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'caption_alignment',
			array(
				'label'     => esc_html__( 'Caption Alignment', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__caption' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'caption_spacing',
			array(
				'label'      => esc_html__( 'Caption Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__caption' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Header Row ──────────────────────────────────────────
		$this->start_controls_section(
			'section_general_style_header',
			array(
				'label'     => esc_html__( 'Header Row', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $general_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'header_bg',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				// Also paints the column headings Pivot Rows injects on
				// mobile. The real <thead> is hidden in that mode, so those
				// injected labels ARE the header row there and follow it
				// rather than silently losing its background. The Pivot Rows
				// Mode section can override them on their own.
				'selector' => '{{WRAPPER}} .kdna-table--general thead .kdna-table__cell, {{WRAPPER}} [data-responsive-mode="pivot_rows"] .kdna-table--general .kdna-table__cell::before',
			)
		);

		$this->add_control(
			'header_text_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-table-header-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'header_typography',
				'selector' => '{{WRAPPER}} .kdna-table--general thead .kdna-table__cell',
			)
		);

		$this->add_responsive_control(
			'header_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-table-header-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'header_text_align',
			array(
				'label'                => esc_html__( 'Text Alignment', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::CHOOSE,
				'options'              => array(
					'inherit' => array(
						'title' => esc_html__( 'Inherit', 'kdna-tables' ),
						'icon'  => 'eicon-undo',
					),
					'left'    => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'  => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'   => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'              => 'inherit',
				'selectors_dictionary' => array(
					'inherit' => '',
				),
				'selectors'            => array(
					'{{WRAPPER}} .kdna-table--general thead .kdna-table__cell' => 'text-align: {{VALUE}};',
				),
				'description'          => esc_html__( 'Inherit keeps per-column and per-cell alignment.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'header_divider_heading',
			array(
				'label'     => esc_html__( 'Bottom Divider', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->register_line_controls(
			'header_divider',
			'--kdna-table-header-divider',
			esc_html__( 'Default (solid)', 'kdna-tables' ),
			esc_html__( 'The single line under the header row. None removes it.', 'kdna-tables' )
		);

		$this->add_control(
			'header_v_lines_heading',
			array(
				'label'     => esc_html__( 'Vertical Lines', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->register_line_controls(
			'header_v_line',
			'--kdna-table-header-v-line',
			esc_html__( 'Match Body Cells', 'kdna-tables' ),
			esc_html__( 'Lines between the header cells. None removes them; left unset they follow the Body Cells vertical lines.', 'kdna-tables' )
		);

		$this->end_controls_section();

		// ─── Section: First Column ────────────────────────────────────────
		/*
		 * These styles target .kdna-table__cell--first-col, which every
		 * first-column body cell carries regardless of whether the table
		 * marks that column as a header. Earlier builds targeted
		 * .kdna-table__cell--row-header instead, so the whole section did
		 * nothing unless the "first column is header" flag happened to be
		 * on in the table content — and even then the background lost the
		 * cascade to the odd/even row rules. The selectors below carry one
		 * more class than the Body Cells row-background selectors so they
		 * win outright.
		 */
		$this->start_controls_section(
			'section_general_style_first_col',
			array(
				'label'     => esc_html__( 'First Column', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $general_condition,
			)
		);

		$this->add_control(
			'first_col_bg',
			array(
				'label'     => esc_html__( 'Background Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					self::FIRST_COL_SELECTOR => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'first_col_text_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					self::FIRST_COL_SELECTOR => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'first_col_typography',
				'selector' => self::FIRST_COL_SELECTOR,
			)
		);

		$this->add_responsive_control(
			'first_col_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					self::FIRST_COL_SELECTOR => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'first_col_edge_heading',
			array(
				'label'     => esc_html__( 'Right Edge Line', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->register_line_controls(
			'first_col_edge',
			'--kdna-table-first-col-edge',
			esc_html__( 'Match Body Cells', 'kdna-tables' ),
			esc_html__( 'The line to the right of the first column. None removes just that line; left unset it follows the Body Cells vertical lines.', 'kdna-tables' )
		);

		$this->end_controls_section();

		// ─── Section: Body Cells ──────────────────────────────────────────
		$this->start_controls_section(
			'section_general_style_body',
			array(
				'label'     => esc_html__( 'Body Cells', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $general_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'body_bg_odd',
				'label'    => esc_html__( 'Odd Row Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-table--general tbody .kdna-table__row--odd > .kdna-table__cell',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'body_bg_even',
				'label'    => esc_html__( 'Even Row Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-table--general tbody .kdna-table__row--even > .kdna-table__cell',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'body_typography',
				'selector' => '{{WRAPPER}} .kdna-table--general tbody .kdna-table__cell',
			)
		);

		$this->add_control(
			'body_text_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-table-body-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'body_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-table-body-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'body_text_align',
			array(
				'label'                => esc_html__( 'Text Alignment', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::CHOOSE,
				'options'              => array(
					'inherit' => array(
						'title' => esc_html__( 'Inherit', 'kdna-tables' ),
						'icon'  => 'eicon-undo',
					),
					'left'    => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'  => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'   => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'              => 'inherit',
				'selectors_dictionary' => array(
					'inherit' => '',
				),
				'selectors'            => array(
					'{{WRAPPER}} .kdna-table--general tbody .kdna-table__cell' => 'text-align: {{VALUE}};',
				),
				'description'          => esc_html__( 'Inherit keeps per-column and per-cell alignment.', 'kdna-tables' ),
			)
		);

		/*
		 * Rule lines are split by axis instead of the old per-side border
		 * group. The general table never draws an outer frame — that is
		 * the Table Wrapper border's job — so these only paint between
		 * cells, and each axis can be removed on its own with None.
		 */
		$this->add_control(
			'body_h_lines_heading',
			array(
				'label'     => esc_html__( 'Horizontal Lines', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->register_line_controls(
			'body_h_line',
			'--kdna-table-h-line',
			esc_html__( 'Default (solid)', 'kdna-tables' ),
			esc_html__( 'Lines between body rows. None removes them.', 'kdna-tables' )
		);

		$this->add_control(
			'body_v_lines_heading',
			array(
				'label'     => esc_html__( 'Vertical Lines', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->register_line_controls(
			'body_v_line',
			'--kdna-table-v-line',
			esc_html__( 'Default (solid)', 'kdna-tables' ),
			esc_html__( 'Lines between columns. None removes them.', 'kdna-tables' )
		);

		$this->add_control(
			'row_hover_bg',
			array(
				'label'     => esc_html__( 'Row Hover Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .kdna-table--general tbody .kdna-table__row:hover > .kdna-table__cell' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'row_hover_transition_duration',
			array(
				'label'       => esc_html__( 'Hover Transition (ms)', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 2000,
				'step'        => 10,
				'default'     => 200,
				'selectors'   => array(
					'{{WRAPPER}}' => '--kdna-table-row-hover-transition: {{VALUE}}ms;',
				),
				'description' => esc_html__( 'Duration applied to row hover background transitions.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();

		// ─── Section: Cell Content ────────────────────────────────────────
		$this->start_controls_section(
			'section_general_style_content',
			array(
				'label'     => esc_html__( 'Cell Content', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $general_condition,
			)
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array( 'min' => 8, 'max' => 200, 'step' => 1 ),
					'em' => array( 'min' => 0.5, 'max' => 10, 'step' => 0.1 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-table-icon-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-table-icon-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'icon_color_hover',
			array(
				'label'     => esc_html__( 'Icon Hover Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__cell:hover .kdna-table__cell-icon' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_spacing',
			array(
				'label'      => esc_html__( 'Icon Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 60, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-table-cell-gap: {{SIZE}}{{UNIT}};',
				),
				'description' => esc_html__( 'Gap between an icon and adjacent text or image in a mixed cell.', 'kdna-tables' ),
			)
		);

		$this->add_responsive_control(
			'image_width',
			array(
				'label'      => esc_html__( 'Image Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 10, 'max' => 600, 'step' => 1 ),
					'%'  => array( 'min' => 1, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__cell-image img' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'image_height',
			array(
				'label'      => esc_html__( 'Image Height', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 10, 'max' => 600, 'step' => 1 ),
					'%'  => array( 'min' => 1, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__cell-image img' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'image_border_radius',
			array(
				'label'      => esc_html__( 'Image Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__cell-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'image_object_fit',
			array(
				'label'     => esc_html__( 'Image Fit', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'options'   => array(
					'cover'   => esc_html__( 'Cover', 'kdna-tables' ),
					'contain' => esc_html__( 'Contain', 'kdna-tables' ),
					'fill'    => esc_html__( 'Fill', 'kdna-tables' ),
					'none'    => esc_html__( 'None', 'kdna-tables' ),
				),
				'default'   => 'cover',
				'selectors' => array(
					'{{WRAPPER}} .kdna-table--general .kdna-table__cell-image img' => 'object-fit: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Table Layout ────────────────────────────────────────
		$this->start_controls_section(
			'section_general_style_layout',
			array(
				'label'     => esc_html__( 'Table Layout', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $general_condition,
			)
		);

		$this->add_control(
			'border_collapse',
			array(
				'label'                => esc_html__( 'Border Collapse', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::SWITCHER,
				'label_on'             => esc_html__( 'On', 'kdna-tables' ),
				'label_off'            => esc_html__( 'Off', 'kdna-tables' ),
				'return_value'         => 'yes',
				'default'              => 'yes',
				'selectors_dictionary' => array(
					'yes' => 'collapse',
					''    => 'separate',
				),
				'selectors'            => array(
					'{{WRAPPER}} .kdna-table--general' => 'border-collapse: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'border_spacing',
			array(
				'label'      => esc_html__( 'Border Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 30, 'step' => 1 ),
				),
				'condition'  => array(
					'border_collapse' => '',
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-table--general' => 'border-spacing: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_comparison_content_controls() {
		$comparison_condition = array( 'selected_table_type' => 'comparison' );


		// ─── Section: Cell Indicators ─────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_indicators',
			array(
				'label'     => esc_html__( 'Cell Indicators', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => $comparison_condition,
			)
		);

		$this->add_control(
			'available_icon',
			array(
				'label'   => esc_html__( 'Available Icon', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => array(
					'value'   => 'fas fa-check',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'unavailable_mode',
			array(
				'label'   => esc_html__( 'Unavailable Indicator', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'icon'   => esc_html__( 'Icon', 'kdna-tables' ),
					'text'   => esc_html__( 'Text', 'kdna-tables' ),
					'hidden' => esc_html__( 'Hidden', 'kdna-tables' ),
				),
				'default' => 'icon',
			)
		);

		$this->add_control(
			'unavailable_icon',
			array(
				'label'     => esc_html__( 'Unavailable Icon', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-minus',
					'library' => 'fa-solid',
				),
				'condition' => array( 'unavailable_mode' => 'icon' ),
			)
		);

		$this->add_control(
			'unavailable_text',
			array(
				'label'     => esc_html__( 'Unavailable Text', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => '-',
				'condition' => array( 'unavailable_mode' => 'text' ),
			)
		);

		$this->end_controls_section();

		// ─── Section: Features Heading ────────────────────────────────────
		// Optional label for the top-left corner cell (the empty <th> above
		// the feature labels column). Leave blank to keep the cell empty.
		$this->start_controls_section(
			'section_comparison_features_heading',
			array(
				'label'     => esc_html__( 'Features Heading', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => $comparison_condition,
			)
		);

		$this->add_control(
			'features_heading_text',
			array(
				'label'       => esc_html__( 'Heading Text', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => esc_html__( 'e.g. Feature / Inclusion', 'kdna-tables' ),
				'description' => esc_html__( 'Shown in the top-left corner cell above the feature labels. Leave blank to keep the cell empty.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();

	}

	protected function register_comparison_style_controls() {
		$cmp_condition         = array( 'selected_table_type' => 'comparison' );
		$highlight_selector    = '{{WRAPPER}} .kdna-comparison--has-highlight .kdna-comparison__cell--highlighted';
		$highlight_card_sel    = '{{WRAPPER}} .kdna-comparison--has-highlight .kdna-comparison__item--highlighted';
		$wrapper_selector      = '{{WRAPPER}} .kdna-table__wrapper--comparison';

		// ─── Section: Table Wrapper ───────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_wrapper',
			array(
				'label'     => esc_html__( 'Table Wrapper', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'cmp_wrapper_background',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => $wrapper_selector,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'cmp_wrapper_border',
				'selector' => $wrapper_selector,
			)
		);

		$this->add_responsive_control(
			'cmp_wrapper_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'cmp_wrapper_box_shadow',
				'selector' => $wrapper_selector,
			)
		);

		$this->add_responsive_control(
			'cmp_wrapper_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					$wrapper_selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'cmp_wrapper_max_width',
			array(
				'label'      => esc_html__( 'Max Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 100, 'max' => 1600, 'step' => 1 ),
					'%'  => array( 'min' => 1, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					$wrapper_selector => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'cmp_wrapper_alignment',
			array(
				'label'                => esc_html__( 'Alignment', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::CHOOSE,
				'options'              => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'              => 'center',
				'selectors_dictionary' => array(
					'left'   => 'margin-right: auto; margin-left: 0;',
					'center' => 'margin-left: auto; margin-right: auto;',
					'right'  => 'margin-left: auto; margin-right: 0;',
				),
				'selectors'            => array(
					$wrapper_selector => '{{VALUE}}',
				),
				'condition'            => array(
					'cmp_wrapper_max_width[size]!' => '',
				),
			)
		);

		// Column divider: opt-in vertical line between columns. Writes to
		// border-right on every cell, so the line shows between adjacent
		// columns. The companion control below cancels border-right on the
		// last cell of every row so the rightmost edge stays clean.
		$this->add_control(
			'column_divider_heading',
			array(
				'label'     => esc_html__( 'Vertical Column Dividers', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'description' => esc_html__( 'Vertical lines between columns. Set Border Type to None to remove them.', 'kdna-tables' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'           => 'column_divider_border',
				'label'          => esc_html__( 'Column Divider', 'kdna-tables' ),
				'selector'       => '{{WRAPPER}} .kdna-comparison .kdna-comparison__cell',
				'fields_options' => array(
					'border' => array(
						'selectors' => array(
							'{{SELECTOR}}' => 'border-right-style: {{VALUE}};',
						),
					),
					'width'  => array(
						// "Column Divider" is a right-edge border; read RIGHT
						// from the width dimensions input.
						'selectors' => array(
							'{{SELECTOR}}' => 'border-right-width: {{RIGHT}}{{UNIT}};',
						),
					),
					'color'  => array(
						'selectors' => array(
							'{{SELECTOR}}' => 'border-right-color: {{VALUE}};',
						),
					),
				),
			)
		);
		$this->add_control(
			'column_divider_strip_outer',
			array(
				'type'      => \Elementor\Controls_Manager::HIDDEN,
				'default'   => 'yes',
				'selectors' => array(
					'{{WRAPPER}} .kdna-comparison .kdna-comparison__row > :last-child' => 'border-right: 0;',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Items Header Row ────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_header',
			array(
				'label'     => esc_html__( 'Items Header Row', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'cmp_header_bg',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'fields_options' => array(
					'background' => array(
						'default' => 'classic',
					),
					'color' => array(
						'default' => '#000000',
					),
				),
				'selector' => '{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell',
			)
		);

		$this->add_responsive_control(
			'cmp_header_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-header-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'cmp_header_min_height',
			array(
				'label'      => esc_html__( 'Minimum Height', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 400, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell' => 'min-height: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'cmp_header_vertical_align',
			array(
				'label'     => esc_html__( 'Vertical Alignment', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'top'    => array(
						'title' => esc_html__( 'Top', 'kdna-tables' ),
						'icon'  => 'eicon-v-align-top',
					),
					'middle' => array(
						'title' => esc_html__( 'Middle', 'kdna-tables' ),
						'icon'  => 'eicon-v-align-middle',
					),
					'bottom' => array(
						'title' => esc_html__( 'Bottom', 'kdna-tables' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'default'   => 'bottom',
				'selectors' => array(
					'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell' => 'vertical-align: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Features Heading ────────────────────────────────────
		// Styles the corner cell heading set in Content > Features Heading.
		// Conditioned on the heading being non-empty so the section stays
		// hidden until the user actually adds text.
		$features_heading_sel = '{{WRAPPER}} .kdna-comparison__features-heading';
		$features_heading_cell_sel = '{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell--head-label';

		$this->start_controls_section(
			'section_comparison_style_features_heading',
			array(
				'label'     => esc_html__( 'Features Heading', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array_merge( $cmp_condition, array( 'features_heading_text!' => '' ) ),
			)
		);

		$this->add_control(
			'features_heading_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					$features_heading_sel => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'features_heading_typography',
				'selector' => $features_heading_sel,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'features_heading_bg',
				'label'    => esc_html__( 'Cell Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => $features_heading_cell_sel,
			)
		);

		$this->add_responsive_control(
			'features_heading_padding',
			array(
				'label'      => esc_html__( 'Cell Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					$features_heading_cell_sel => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'features_heading_radius',
			array(
				'label'      => esc_html__( 'Cell Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					$features_heading_cell_sel => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'features_heading_align_note',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Text alignment follows the Feature Label Column → Label Alignment setting.', 'kdna-tables' ),
				'content_classes' => 'elementor-descriptor',
			)
		);

		$this->end_controls_section();

		// ─── Section: Column Styling ──────────────────────────────────────
		// Per-column background and border radius. The data model caps items
		// at six, so we register six slots; controls left empty emit no CSS
		// and have no effect, so unused slots are inert.
		$this->start_controls_section(
			'section_comparison_style_columns',
			array(
				'label'     => esc_html__( 'Column Styling', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_control(
			'cmp_columns_intro',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Background, text colour, border radius, row dividers, and spacing for each column. Per-column divider settings override the global Horizontal Row Dividers (Feature Rows section).', 'kdna-tables' ),
				'content_classes' => 'elementor-descriptor',
			)
		);

		$this->add_responsive_control(
			'cmp_column_spacing',
			array(
				'label'       => esc_html__( 'Spacing Between Columns', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'size_units'  => array( 'px' ),
				'range'       => array(
					'px' => array( 'min' => 0, 'max' => 60, 'step' => 1 ),
				),
				'default'     => array( 'unit' => 'px', 'size' => 0 ),
				'selectors'   => array(
					'{{WRAPPER}} .kdna-comparison' => 'border-spacing: {{SIZE}}{{UNIT}} 0;',
				),
				'description' => esc_html__( 'Horizontal gap between columns. Combine with per-column Background + Border Radius for the card-per-column look.', 'kdna-tables' ),
			)
		);

		for ( $slot = 1; $slot <= 6; $slot++ ) {
			// Show this slot only when the picked table has at least $slot
			// items. The first slot is always available because a comparison
			// table requires at least two items, but rather than special-case
			// it we still gate it on count >= 1 for symmetry.
			$slot_condition = array(
				'selected_table_item_count' => array_map( 'strval', range( $slot, 6 ) ),
			);

			$this->add_control(
				'cmp_col_' . $slot . '_heading',
				array(
					/* translators: %d: column number. */
					'label'     => sprintf( esc_html__( 'Column %d', 'kdna-tables' ), $slot ),
					'type'      => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
					'condition' => $slot_condition,
				)
			);

			$this->add_control(
				'cmp_col_' . $slot . '_bg',
				array(
					'label'     => esc_html__( 'Background', 'kdna-tables' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell--item-' . $slot => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--item-' . $slot => 'background-color: {{VALUE}};',
						// Beat the responsive card_stack/pivot_rows tbody bg
						// rule (specificity 0-5-1) so per-column backgrounds
						// still apply on mobile. The extra attribute hooks
						// raise this selector to 0-6-1.
						'{{WRAPPER}} .kdna-table__wrapper[data-responsive-mode][data-responsive-breakpoint] .kdna-comparison thead .kdna-comparison__cell--item-' . $slot => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .kdna-table__wrapper[data-responsive-mode][data-responsive-breakpoint] .kdna-comparison tbody .kdna-comparison__cell--item-' . $slot => 'background-color: {{VALUE}};',
					),
					'condition' => $slot_condition,
				)
			);

			$this->add_control(
				'cmp_col_' . $slot . '_text_color',
				array(
					'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'description' => esc_html__( 'Overrides header and body text colours for this column.', 'kdna-tables' ),
					'selectors' => array(
						'{{WRAPPER}} .kdna-comparison .kdna-comparison__cell--item-' . $slot . ', {{WRAPPER}} .kdna-comparison .kdna-comparison__cell--item-' . $slot . ' .kdna-comparison__item-label, {{WRAPPER}} .kdna-comparison .kdna-comparison__cell--item-' . $slot . ' .kdna-comparison__item-sublabel, {{WRAPPER}} .kdna-comparison .kdna-comparison__cell--item-' . $slot . ' .kdna-table__cell-text' => 'color: {{VALUE}};',
						// High-specificity variant so card_stack/pivot_rows
						// mobile rules cannot mask the column text colour.
						'{{WRAPPER}} .kdna-table__wrapper[data-responsive-mode][data-responsive-breakpoint] .kdna-comparison .kdna-comparison__cell--item-' . $slot => 'color: {{VALUE}};',
					),
					'condition' => $slot_condition,
				)
			);

			$this->add_responsive_control(
				'cmp_col_' . $slot . '_radius',
				array(
					'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
					'type'       => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell--item-' . $slot => 'border-top-left-radius: {{TOP}}{{UNIT}}; border-top-right-radius: {{RIGHT}}{{UNIT}};',
						'{{WRAPPER}} .kdna-comparison tbody tr:last-child > .kdna-comparison__cell--item-' . $slot => 'border-bottom-right-radius: {{BOTTOM}}{{UNIT}}; border-bottom-left-radius: {{LEFT}}{{UNIT}};',
					),
					'condition'  => $slot_condition,
				)
			);

			// Per-column row divider. The chained `.cell.cell--item-N` raises
			// the selector to 0-3-1, beating the global Horizontal Row Dividers
			// rule (0-2-1) regardless of section emission order. Includes the
			// thead cell so the header divider's slice picks up the per-column
			// colour/width too.
			$col_divider_sel = '{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell.kdna-comparison__cell--item-' . $slot . ', {{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell.kdna-comparison__cell--item-' . $slot;

			$this->add_control(
				'cmp_col_' . $slot . '_divider_style',
				array(
					'label'     => esc_html__( 'Row Divider Style', 'kdna-tables' ),
					'type'      => \Elementor\Controls_Manager::SELECT,
					'options'   => array(
						''       => esc_html__( 'Inherit from global', 'kdna-tables' ),
						'none'   => esc_html__( 'None', 'kdna-tables' ),
						'solid'  => esc_html__( 'Solid', 'kdna-tables' ),
						'dashed' => esc_html__( 'Dashed', 'kdna-tables' ),
						'dotted' => esc_html__( 'Dotted', 'kdna-tables' ),
						'double' => esc_html__( 'Double', 'kdna-tables' ),
					),
					'default'   => '',
					'selectors' => array(
						$col_divider_sel => 'border-bottom-style: {{VALUE}};',
					),
					'condition' => $slot_condition,
				)
			);

			$this->add_responsive_control(
				'cmp_col_' . $slot . '_divider_width',
				array(
					'label'      => esc_html__( 'Row Divider Width', 'kdna-tables' ),
					'type'       => \Elementor\Controls_Manager::SLIDER,
					'size_units' => array( 'px' ),
					'range'      => array(
						'px' => array( 'min' => 0, 'max' => 10, 'step' => 1 ),
					),
					'selectors'  => array(
						$col_divider_sel => 'border-bottom-width: {{SIZE}}{{UNIT}};',
					),
					'condition'  => $slot_condition,
				)
			);

			$this->add_control(
				'cmp_col_' . $slot . '_divider_color',
				array(
					'label'     => esc_html__( 'Row Divider Colour', 'kdna-tables' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						$col_divider_sel => 'border-bottom-color: {{VALUE}};',
					),
					'condition' => $slot_condition,
				)
			);
		}

		$this->end_controls_section();

		// ─── Section: Item Card ───────────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_item_card',
			array(
				'label'     => esc_html__( 'Item Card', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_responsive_control(
			'item_image_width',
			array(
				'label'      => esc_html__( 'Image Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 10, 'max' => 400, 'step' => 1 ),
					'%'  => array( 'min' => 1, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__item-image img' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_image_height',
			array(
				'label'      => esc_html__( 'Image Height', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 10, 'max' => 400, 'step' => 1 ),
					'%'  => array( 'min' => 1, 'max' => 100, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__item-image img' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_image_border_radius',
			array(
				'label'      => esc_html__( 'Image Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__item-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_image_spacing',
			array(
				'label'      => esc_html__( 'Image Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 60, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-item-image-spacing: {{SIZE}}{{UNIT}};',
				),
				'description' => esc_html__( 'Gap below the image, before the label.', 'kdna-tables' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'item_label_typography',
				'label'    => esc_html__( 'Label Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__item-label',
			)
		);

		$this->add_control(
			'item_label_color',
			array(
				'label'     => esc_html__( 'Label Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-item-label-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'item_sublabel_typography',
				'label'    => esc_html__( 'Sublabel Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__item-sublabel',
			)
		);

		$this->add_control(
			'item_sublabel_color',
			array(
				'label'     => esc_html__( 'Sublabel Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-item-sublabel-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_sublabel_spacing',
			array(
				'label'      => esc_html__( 'Sublabel Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 60, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__item-sublabel' => 'margin-top: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_padding',
			array(
				'label'      => esc_html__( 'Item Card Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'description' => esc_html__( 'Inner padding around the image, label and sublabel.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();

		// ─── Section: Highlighted Item ────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_highlight',
			array(
				'label'     => esc_html__( 'Highlighted Item', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_control(
			'highlight_bg',
			array(
				'label'     => esc_html__( 'Background Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-highlight-bg: {{VALUE}};',
				),
				'description' => esc_html__( 'Applied to the highlighted column body cells.', 'kdna-tables' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'highlight_border',
				'selector' => $highlight_selector . ', ' . $highlight_card_sel,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'highlight_shadow',
				'selector' => $highlight_card_sel,
			)
		);

		$this->add_control(
			'highlight_scale',
			array(
				'label'   => esc_html__( 'Scale', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 0.8,
				'max'     => 1.2,
				'step'    => 0.01,
				'default' => 1,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-highlight-scale: {{VALUE}};',
				),
				'description' => esc_html__( 'Slight scale applied to the highlighted item card.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'badge_heading',
			array(
				'label'     => esc_html__( 'Badge', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'badge_bg',
			array(
				'label'     => esc_html__( 'Badge Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-badge-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_color',
			array(
				'label'     => esc_html__( 'Badge Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-badge-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'badge_typography',
				'label'    => esc_html__( 'Badge Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__badge',
			)
		);

		$this->add_responsive_control(
			'badge_padding',
			array(
				'label'      => esc_html__( 'Badge Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'badge_border',
				'selector' => '{{WRAPPER}} .kdna-comparison__badge',
			)
		);

		$this->add_responsive_control(
			'badge_border_radius',
			array(
				'label'      => esc_html__( 'Badge Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'badge_offset_y',
			array(
				'label'      => esc_html__( 'Badge Offset Y', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => -80, 'max' => 80, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-badge-offset-y: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Feature Rows ────────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_rows',
			array(
				'label'     => esc_html__( 'Feature Rows', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'row_bg_odd',
				'label'    => esc_html__( 'Odd Row Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__row--odd > .kdna-comparison__cell',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'row_bg_even',
				'label'    => esc_html__( 'Even Row Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__row--even > .kdna-comparison__cell',
			)
		);

		$this->add_responsive_control(
			'row_padding',
			array(
				'label'      => esc_html__( 'Row Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-body-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'row_divider_heading',
			array(
				'label'       => esc_html__( 'Horizontal Row Dividers', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::HEADING,
				'separator'   => 'before',
				'description' => esc_html__( 'Horizontal lines between feature rows. Set Style to None to remove them. Per-column dividers in the Column Styling section override these.', 'kdna-tables' ),
			)
		);

		// Explicit style/width/colour controls instead of Group_Control_Border.
		// The group's "None" option only suppressed style — width and colour
		// still emitted, so the base 1px border-bottom from the CSS file kept
		// rendering. With explicit controls and selectors_dictionary, picking
		// None forces both width: 0 and style: none in the same rule.
		$this->add_control(
			'row_divider_style',
			array(
				'label'                => esc_html__( 'Style', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::SELECT,
				'options'              => array(
					''       => esc_html__( 'Default', 'kdna-tables' ),
					'none'   => esc_html__( 'None', 'kdna-tables' ),
					'solid'  => esc_html__( 'Solid', 'kdna-tables' ),
					'dashed' => esc_html__( 'Dashed', 'kdna-tables' ),
					'dotted' => esc_html__( 'Dotted', 'kdna-tables' ),
					'double' => esc_html__( 'Double', 'kdna-tables' ),
				),
				'default'              => '',
				'selectors_dictionary' => array(
					'none'   => 'border-bottom: 0 none;',
					'solid'  => 'border-bottom-style: solid;',
					'dashed' => 'border-bottom-style: dashed;',
					'dotted' => 'border-bottom-style: dotted;',
					'double' => 'border-bottom-style: double;',
				),
				'selectors'            => array(
					'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell, {{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell' => '{{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'row_divider_width',
			array(
				'label'      => esc_html__( 'Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 10, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell, {{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'row_divider_style!' => array( '', 'none' ) ),
			)
		);

		$this->add_control(
			'row_divider_color',
			array(
				'label'     => esc_html__( 'Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell, {{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell' => 'border-bottom-color: {{VALUE}};',
				),
				'condition' => array( 'row_divider_style!' => array( '', 'none' ) ),
			)
		);

		$this->add_control(
			'row_hover_bg',
			array(
				'label'     => esc_html__( 'Row Hover Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__row:hover > .kdna-comparison__cell' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'row_hover_transition_duration',
			array(
				'label'       => esc_html__( 'Hover Transition (ms)', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 2000,
				'step'        => 10,
				'default'     => 200,
				'selectors'   => array(
					'{{WRAPPER}}' => '--kdna-comparison-row-hover-transition: {{VALUE}}ms;',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Feature Label Column ───────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_label_col',
			array(
				'label'     => esc_html__( 'Feature Label Column', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_responsive_control(
			'label_column_width',
			array(
				'label'       => esc_html__( 'Column Width', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'size_units'  => array( '%', 'px', 'vw' ),
				'range'       => array(
					'%'  => array( 'min' => 5, 'max' => 80, 'step' => 1 ),
					'px' => array( 'min' => 60, 'max' => 800, 'step' => 1 ),
					'vw' => array( 'min' => 5, 'max' => 80, 'step' => 1 ),
				),
				'default'     => array(
					'unit' => '%',
					'size' => 25,
				),
				'selectors'   => array(
					'{{WRAPPER}}' => '--kdna-comparison-label-column-width: {{SIZE}}{{UNIT}};',
				),
				'description' => esc_html__( 'Width of the feature label column. The item columns share the remaining width equally.', 'kdna-tables' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'label_bg',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--label',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'feature_label_typography',
				'label'    => esc_html__( 'Label Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__feature-label',
			)
		);

		$this->add_control(
			'feature_label_color',
			array(
				'label'     => esc_html__( 'Label Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-label-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'feature_description_typography',
				'label'    => esc_html__( 'Description Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__feature-description',
			)
		);

		$this->add_control(
			'feature_description_color',
			array(
				'label'     => esc_html__( 'Description Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-label-description-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'feature_description_spacing',
			array(
				'label'      => esc_html__( 'Description Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 40, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__feature-description' => 'margin-top: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'feature_label_alignment',
			array(
				'label'     => esc_html__( 'Label Alignment', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					// Apply to both body label cells AND the corner cell so
					// the Features Heading (when set) follows the same
					// alignment as the row labels in this column.
					'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--label, {{WRAPPER}} .kdna-comparison thead .kdna-comparison__cell--head-label' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'info_icon_heading',
			array(
				'label'     => esc_html__( 'Info Icon', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'info_icon_color',
			array(
				'label'     => esc_html__( 'Icon Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .kdna-comparison__tooltip-icon' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'info_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array( 'min' => 8, 'max' => 40, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__tooltip-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'info_icon_spacing',
			array(
				'label'      => esc_html__( 'Icon Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 40, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__tooltip-wrap' => 'margin-left: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Available Indicator ─────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_available',
			array(
				'label'     => esc_html__( 'Available Indicator', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_control(
			'available_icon_color',
			array(
				'label'     => esc_html__( 'Icon Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-available-color: {{VALUE}};',
				),
				'description' => esc_html__( 'Colour of the tick or check icon. Baseline default is white so it reads on the blue circle background.', 'kdna-tables' ),
			)
		);

		$this->add_responsive_control(
			'available_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array( 'min' => 8, 'max' => 80, 'step' => 1 ),
					'em' => array( 'min' => 0.5, 'max' => 4, 'step' => 0.1 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 26,
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-available-icon-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'available_icon_bg',
			array(
				'label'     => esc_html__( 'Background Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-available-bg: {{VALUE}};',
				),
				'description' => esc_html__( 'Background colour of the shape behind the icon.', 'kdna-tables' ),
			)
		);

		$this->add_responsive_control(
			'available_icon_bg_size',
			array(
				'label'      => esc_html__( 'Shape Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 10, 'max' => 120, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-available-shape-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'available_icon_bg_shape',
			array(
				'label'                => esc_html__( 'Shape', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::CHOOSE,
				'options'              => array(
					'circle'         => array(
						'title' => esc_html__( 'Circle', 'kdna-tables' ),
						'icon'  => 'eicon-circle',
					),
					'square'         => array(
						'title' => esc_html__( 'Square', 'kdna-tables' ),
						'icon'  => 'eicon-square',
					),
					'rounded-square' => array(
						'title' => esc_html__( 'Rounded Square', 'kdna-tables' ),
						'icon'  => 'eicon-frame-expand',
					),
					'none'           => array(
						'title' => esc_html__( 'None', 'kdna-tables' ),
						'icon'  => 'eicon-ban',
					),
				),
				'default'              => 'circle',
				'selectors_dictionary' => array(
					'circle'         => '50%',
					'square'         => '0',
					'rounded-square' => '8px',
					'none'           => '0',
				),
				'selectors'            => array(
					'{{WRAPPER}}' => '--kdna-comparison-available-shape-radius: {{VALUE}};',
				),
				'description' => esc_html__( 'Pick a shape, or set Background to transparent for no shape behind the icon.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();

		// ─── Section: Unavailable Indicator ───────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_unavailable',
			array(
				'label'     => esc_html__( 'Unavailable Indicator', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_control(
			'unavailable_color',
			array(
				'label'     => esc_html__( 'Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-unavailable-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'unavailable_size',
			array(
				'label'      => esc_html__( 'Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array( 'min' => 8, 'max' => 60, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-unavailable-size: {{SIZE}}{{UNIT}};',
				),
				'description' => esc_html__( 'Font size for text mode, icon font size for icon mode.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'unavailable_bg',
			array(
				'label'       => esc_html__( 'Background Colour', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::COLOR,
				'selectors'   => array(
					'{{WRAPPER}}' => '--kdna-comparison-unavailable-bg: {{VALUE}};',
				),
				'description' => esc_html__( 'Background colour of the shape behind the indicator.', 'kdna-tables' ),
				'condition'   => array(
					'unavailable_mode!' => 'hidden',
				),
			)
		);

		$this->add_responsive_control(
			'unavailable_bg_size',
			array(
				'label'      => esc_html__( 'Shape Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 10, 'max' => 120, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-unavailable-shape-size: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'unavailable_mode!' => 'hidden',
				),
			)
		);

		$this->add_control(
			'unavailable_bg_shape',
			array(
				'label'                => esc_html__( 'Shape', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::CHOOSE,
				'options'              => array(
					'circle'         => array(
						'title' => esc_html__( 'Circle', 'kdna-tables' ),
						'icon'  => 'eicon-circle',
					),
					'square'         => array(
						'title' => esc_html__( 'Square', 'kdna-tables' ),
						'icon'  => 'eicon-square',
					),
					'rounded-square' => array(
						'title' => esc_html__( 'Rounded Square', 'kdna-tables' ),
						'icon'  => 'eicon-frame-expand',
					),
					'none'           => array(
						'title' => esc_html__( 'None', 'kdna-tables' ),
						'icon'  => 'eicon-ban',
					),
				),
				'default'              => 'circle',
				'selectors_dictionary' => array(
					'circle'         => '50%',
					'square'         => '0',
					'rounded-square' => '8px',
					'none'           => '0',
				),
				'selectors'            => array(
					'{{WRAPPER}}' => '--kdna-comparison-unavailable-shape-radius: {{VALUE}};',
				),
				'description'          => esc_html__( 'Pick a shape, or set Background to transparent for no shape behind the indicator.', 'kdna-tables' ),
				'condition'            => array(
					'unavailable_mode!' => 'hidden',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'unavailable_typography',
				'label'     => esc_html__( 'Typography', 'kdna-tables' ),
				'selector'  => '{{WRAPPER}} .kdna-comparison__indicator--unavailable.kdna-comparison__indicator--text',
				'condition' => array(
					'unavailable_mode' => 'text',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Cell Value Text ─────────────────────────────────────
		// Styles the text-typed content that replaces the tick / cross in
		// custom cells (e.g. 'Yours at end of term', 'N/A', 'Device bond').
		$this->start_controls_section(
			'section_comparison_style_value',
			array(
				'label'     => esc_html__( 'Cell Value Text', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_control(
			'value_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'value_typography',
				'label'    => esc_html__( 'Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value, {{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value .kdna-table__cell-text',
			)
		);

		$this->add_responsive_control(
			'value_text_align',
			array(
				'label'     => esc_html__( 'Alignment', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Centre', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'kdna-tables' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors'   => array(
					// Desktop selector only. The high-specificity variant that
					// used to sit alongside it pinned this alignment through
					// card_stack and pivot_rows as well; those modes now always
					// centre, so it would fight them.
					'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value' => 'text-align: {{VALUE}};',
				),
				'description' => esc_html__( 'Applies to the desktop layout. Responsive modes centre their cells.', 'kdna-tables' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			array(
				'name'     => 'value_text_shadow',
				'label'    => esc_html__( 'Text Shadow', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value',
			)
		);

		$this->end_controls_section();

		// ─── Section: Cell Icon (Mixed) ───────────────────────────────────
		// Styles the icon that appears beside text in a Custom feature cell
		// (cell_type = mixed, arrangement icon-text / text-icon). Position
		// stays per-cell; this section governs colour, size, and gap.
		$this->start_controls_section(
			'section_comparison_style_cell_icon',
			array(
				'label'     => esc_html__( 'Cell Icon (Mixed)', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$cmp_cell_icon_sel = '{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value .kdna-table__cell-icon';

		$this->add_control(
			'cmp_cell_icon_position',
			array(
				'label'   => esc_html__( 'Icon Position', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'inherit',
				'options' => array(
					'inherit' => esc_html__( 'Per cell (use editor setting)', 'kdna-tables' ),
					'before'  => esc_html__( 'Before text', 'kdna-tables' ),
					'after'   => esc_html__( 'After text', 'kdna-tables' ),
				),
				'description' => esc_html__( 'Overrides the icon/text order chosen in the table editor for every mixed cell.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'cmp_cell_icon_color',
			array(
				'label'     => esc_html__( 'Icon Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					$cmp_cell_icon_sel => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'cmp_cell_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array( 'min' => 8, 'max' => 96, 'step' => 1 ),
					'em' => array( 'min' => 0.5, 'max' => 6, 'step' => 0.1 ),
				),
				'selectors'  => array(
					$cmp_cell_icon_sel => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'cmp_cell_icon_spacing',
			array(
				'label'       => esc_html__( 'Spacing from Text', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'size_units'  => array( 'px' ),
				'range'       => array(
					'px' => array( 'min' => 0, 'max' => 40, 'step' => 1 ),
				),
				'selectors'   => array(
					'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value .kdna-table__cell-text + .kdna-table__cell-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .kdna-comparison tbody .kdna-comparison__cell--value .kdna-table__cell-icon + .kdna-table__cell-text' => 'margin-left: {{SIZE}}{{UNIT}};',
				),
				'description' => esc_html__( 'Gap between the icon and the adjacent text in a mixed cell.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();

		// ─── Section: CTA Button ──────────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_cta',
			array(
				'label'     => esc_html__( 'CTA Button', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'cta_typography',
				'selector' => '{{WRAPPER}} .kdna-comparison__cta',
			)
		);

		$this->start_controls_tabs( 'cta_state_tabs' );

		$this->start_controls_tab(
			'cta_state_normal',
			array( 'label' => esc_html__( 'Normal', 'kdna-tables' ) )
		);

		$this->add_control(
			'cta_text_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-cta-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'cta_bg',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__cta',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'cta_border',
				'selector' => '{{WRAPPER}} .kdna-comparison__cta',
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cta_state_hover',
			array( 'label' => esc_html__( 'Hover', 'kdna-tables' ) )
		);

		$this->add_control(
			'cta_text_color_hover',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-cta-hover-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'cta_bg_hover',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__cta:hover, {{WRAPPER}} .kdna-comparison__cta:focus',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'cta_border_hover',
				'selector' => '{{WRAPPER}} .kdna-comparison__cta:hover, {{WRAPPER}} .kdna-comparison__cta:focus',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'cta_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__cta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'cta_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__cta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'cta_full_width',
			array(
				'label'                => esc_html__( 'Full Width', 'kdna-tables' ),
				'type'                 => \Elementor\Controls_Manager::SWITCHER,
				'label_on'             => esc_html__( 'On', 'kdna-tables' ),
				'label_off'            => esc_html__( 'Off', 'kdna-tables' ),
				'return_value'         => 'yes',
				'default'              => '',
				'selectors_dictionary' => array(
					'yes' => 'display: flex; width: 100%;',
					''    => 'display: inline-flex; width: auto;',
				),
				'selectors'            => array(
					'{{WRAPPER}} .kdna-comparison__cta' => '{{VALUE}}',
				),
			)
		);

		$this->add_control(
			'cta_icon',
			array(
				'label'     => esc_html__( 'Icon', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'cta_icon_position',
			array(
				'label'     => esc_html__( 'Icon Position', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'before' => array(
						'title' => esc_html__( 'Before', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-left',
					),
					'after'  => array(
						'title' => esc_html__( 'After', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'after',
				'condition' => array(
					'cta_icon[value]!' => '',
				),
			)
		);

		$this->add_responsive_control(
			'cta_icon_spacing',
			array(
				'label'      => esc_html__( 'Icon Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 40, 'step' => 1 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 8,
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-comparison-cta-icon-spacing: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'cta_icon[value]!' => '',
				),
			)
		);

		$this->add_control(
			'cta_transition_duration',
			array(
				'label'     => esc_html__( 'Transition (ms)', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 2000,
				'step'      => 10,
				'default'   => 150,
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-comparison-cta-transition: {{VALUE}}ms;',
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Tooltip ────────────────────────────────────────────
		$this->start_controls_section(
			'section_comparison_style_tooltip',
			array(
				'label'     => esc_html__( 'Tooltip', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => $cmp_condition,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'tooltip_bg',
				'label'    => esc_html__( 'Background', 'kdna-tables' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .kdna-comparison__tooltip',
			)
		);

		$this->add_control(
			'tooltip_color',
			array(
				'label'     => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-tooltip-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'tooltip_typography',
				'selector' => '{{WRAPPER}} .kdna-comparison__tooltip',
			)
		);

		$this->add_responsive_control(
			'tooltip_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .kdna-comparison__tooltip' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'tooltip_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-tooltip-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'tooltip_max_width',
			array(
				'label'      => esc_html__( 'Max Width', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 80, 'max' => 600, 'step' => 1 ),
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-tooltip-max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'tooltip_arrow_size',
			array(
				'label'      => esc_html__( 'Arrow Size', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 20, 'step' => 1 ),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 6,
				),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-tooltip-arrow-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'tooltip_position',
			array(
				'label'   => esc_html__( 'Position', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'top'    => array(
						'title' => esc_html__( 'Top', 'kdna-tables' ),
						'icon'  => 'eicon-v-align-top',
					),
					'bottom' => array(
						'title' => esc_html__( 'Bottom', 'kdna-tables' ),
						'icon'  => 'eicon-v-align-bottom',
					),
					'auto'   => array(
						'title' => esc_html__( 'Auto', 'kdna-tables' ),
						'icon'  => 'eicon-flip',
					),
				),
				'default' => 'top',
				'description' => esc_html__( 'Auto smart-flips to fit the viewport once the Session 7 tooltip script is in place; until then it follows the Top layout.', 'kdna-tables' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'tooltip_shadow',
				'selector' => '{{WRAPPER}} .kdna-comparison__tooltip',
			)
		);

		$this->end_controls_section();
	}

	protected function register_responsive_content_controls() {
		$this->start_controls_section(
			'section_responsive',
			array(
				'label'     => esc_html__( 'Responsive', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => array(
					'selected_table_id!' => '',
				),
			)
		);

		$this->add_control(
			'responsive_mode',
			array(
				'label'   => esc_html__( 'Responsive Mode', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'none'          => esc_html__( 'None (table stays in place)', 'kdna-tables' ),
					'card_stack'    => esc_html__( 'Card Stack', 'kdna-tables' ),
					'pivot_rows'    => esc_html__( 'Pivot Rows', 'kdna-tables' ),
					'column_picker' => esc_html__( 'Column Picker', 'kdna-tables' ),
				),
				'default' => 'card_stack',
			)
		);

		$this->add_control(
			'responsive_breakpoint',
			array(
				'label'     => esc_html__( 'Activate At', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'options'   => array(
					'mobile'             => esc_html__( 'Mobile only', 'kdna-tables' ),
					'tablet_and_mobile'  => esc_html__( 'Tablet and Mobile', 'kdna-tables' ),
				),
				'default'   => 'mobile',
				'condition' => array(
					'responsive_mode!' => 'none',
				),
			)
		);

		$this->add_control(
			'picker_max_select',
			array(
				'label'     => esc_html__( 'Maximum Selectable', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 2,
				'step'      => 1,
				'default'   => 2,
				'condition' => array( 'responsive_mode' => 'column_picker' ),
			)
		);

		$this->add_control(
			'picker_default_items',
			array(
				'label'       => esc_html__( 'Default Selected Items', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => array(
					'1' => esc_html__( 'Item 1', 'kdna-tables' ),
					'2' => esc_html__( 'Item 2', 'kdna-tables' ),
					'3' => esc_html__( 'Item 3', 'kdna-tables' ),
					'4' => esc_html__( 'Item 4', 'kdna-tables' ),
					'5' => esc_html__( 'Item 5', 'kdna-tables' ),
					'6' => esc_html__( 'Item 6', 'kdna-tables' ),
				),
				'default'     => array( '1', '2' ),
				'condition'   => array( 'responsive_mode' => 'column_picker' ),
				'description' => esc_html__( 'Slot numbers (1 to 6) of the items selected on initial load.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'picker_label_text',
			array(
				'label'     => esc_html__( 'Picker Label', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => esc_html__( 'Compare', 'kdna-tables' ),
				'condition' => array( 'responsive_mode' => 'column_picker' ),
				'dynamic'   => array( 'active' => true ),
			)
		);

		$this->end_controls_section();
	}

	protected function register_responsive_style_controls() {
		// ─── Section: Card Stack Mode ─────────────────────────────────────
		$this->start_controls_section(
			'section_responsive_style_card',
			array(
				'label'     => esc_html__( 'Card Stack Mode', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array(
					'selected_table_id!' => '',
					'responsive_mode'    => 'card_stack',
				),
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => esc_html__( 'Card Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-card-bg: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'card_border',
				'selector' => '{{WRAPPER}} .kdna-table__wrapper [data-responsive-mode="card_stack"] .kdna-table__card, {{WRAPPER}} .kdna-table__wrapper [data-responsive-mode="card_stack"] .kdna-comparison__card',
			)
		);

		$this->add_responsive_control(
			'card_border_radius',
			array(
				'label'      => esc_html__( 'Card Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-card-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'selector' => '{{WRAPPER}} .kdna-table__wrapper [data-responsive-mode="card_stack"] .kdna-table__card, {{WRAPPER}} .kdna-table__wrapper [data-responsive-mode="card_stack"] .kdna-comparison__card',
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => esc_html__( 'Card Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-card-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_spacing',
			array(
				'label'      => esc_html__( 'Card Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80, 'step' => 1 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 16 ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-card-spacing: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_header_sticky',
			array(
				'label'        => esc_html__( 'Sticky Card Header', 'kdna-tables' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'kdna-tables' ),
				'label_off'    => esc_html__( 'Off', 'kdna-tables' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => esc_html__( 'Keeps the item header visible while scrolling within the card.', 'kdna-tables' ),
			)
		);

		$this->end_controls_section();

		// ─── Section: Pivot Rows Mode ─────────────────────────────────────
		$this->start_controls_section(
			'section_responsive_style_pivot',
			array(
				'label'     => esc_html__( 'Pivot Rows Mode', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array(
					'selected_table_id!' => '',
					'responsive_mode'    => 'pivot_rows',
				),
			)
		);

		$this->add_control(
			'pivot_label_position',
			array(
				'label'   => esc_html__( 'Label Position', 'kdna-tables' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'above'  => array(
						'title' => esc_html__( 'Above', 'kdna-tables' ),
						'icon'  => 'eicon-v-align-top',
					),
					'inline' => array(
						'title' => esc_html__( 'Inline', 'kdna-tables' ),
						'icon'  => 'eicon-h-align-left',
					),
				),
				'default' => 'above',
			)
		);

		$this->add_responsive_control(
			'pivot_label_width',
			array(
				'label'      => esc_html__( 'Label Width (%)', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( '%' ),
				'range'      => array( '%' => array( 'min' => 10, 'max' => 80, 'step' => 1 ) ),
				'default'    => array( 'unit' => '%', 'size' => 30 ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-pivot-label-width: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'pivot_label_position' => 'inline' ),
			)
		);

		/*
		 * In Pivot Rows the real <thead> is hidden and every cell injects
		 * its column label instead, so that label is the column heading at
		 * this breakpoint. It inherits the Header Row background and text
		 * colour by default; the controls below restyle it for mobile
		 * without touching the desktop header.
		 */
		$this->add_control(
			'pivot_label_heading',
			array(
				'label'     => esc_html__( 'Column Headings', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'pivot_label_typography',
				'label'    => esc_html__( 'Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} [data-responsive-mode="pivot_rows"] .kdna-table__cell::before, {{WRAPPER}} [data-responsive-mode="pivot_rows"] .kdna-comparison__cell--value::before',
			)
		);

		$this->add_control(
			'pivot_label_color',
			array(
				'label'       => esc_html__( 'Text Colour', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::COLOR,
				'selectors'   => array(
					'{{WRAPPER}}' => '--kdna-pivot-label-color: {{VALUE}};',
				),
				'description' => esc_html__( 'Unset, headings use the Header Row text colour.', 'kdna-tables' ),
			)
		);

		$this->add_control(
			'pivot_heading_bg',
			array(
				'label'       => esc_html__( 'Background Colour', 'kdna-tables' ),
				'type'        => \Elementor\Controls_Manager::COLOR,
				'selectors'   => array(
					// One class more than the Header Row Background control's
					// pivot selector, so setting this overrides the header
					// background for the mobile headings only.
					'{{WRAPPER}} .kdna-table__wrapper[data-responsive-mode="pivot_rows"] .kdna-table--general .kdna-table__cell::before' => 'background: {{VALUE}};',
				),
				'description' => esc_html__( 'Unset, headings use the Header Row background.', 'kdna-tables' ),
			)
		);

		$this->add_responsive_control(
			'pivot_heading_padding',
			array(
				'label'      => esc_html__( 'Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-pivot-heading-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'pivot_heading_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-pivot-heading-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'pivot_heading_spacing',
			array(
				'label'      => esc_html__( 'Spacing Below Heading', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40, 'step' => 1 ) ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-pivot-heading-spacing: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'pivot_label_position' => 'above' ),
			)
		);

		$this->add_responsive_control(
			'pivot_row_spacing',
			array(
				'label'      => esc_html__( 'Row Spacing', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80, 'step' => 1 ) ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-pivot-row-spacing: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'           => 'pivot_divider_border',
				'label'          => esc_html__( 'Row Divider', 'kdna-tables' ),
				'selector'       => '{{WRAPPER}} [data-responsive-mode="pivot_rows"] .kdna-table tbody tr, {{WRAPPER}} [data-responsive-mode="pivot_rows"] .kdna-comparison tbody tr',
				'fields_options' => array(
					'border' => array(
						'selectors' => array(
							'{{SELECTOR}}' => 'border-bottom-style: {{VALUE}};',
						),
					),
					'width'  => array(
						// "Row Divider" is a bottom-edge border; read BOTTOM
						// from the width dimensions input.
						'selectors' => array(
							'{{SELECTOR}}' => 'border-bottom-width: {{BOTTOM}}{{UNIT}};',
						),
					),
					'color'  => array(
						'selectors' => array(
							'{{SELECTOR}}' => 'border-bottom-color: {{VALUE}};',
						),
					),
				),
			)
		);

		$this->end_controls_section();

		// ─── Section: Column Picker Mode ──────────────────────────────────
		$this->start_controls_section(
			'section_responsive_style_picker',
			array(
				'label'     => esc_html__( 'Column Picker Mode', 'kdna-tables' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array(
					'selected_table_id!' => '',
					'responsive_mode'    => 'column_picker',
				),
			)
		);

		$this->add_control(
			'picker_bg',
			array(
				'label'     => esc_html__( 'Picker Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-picker-bg: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'picker_border',
				'selector' => '{{WRAPPER}} .kdna-picker',
			)
		);

		$this->add_responsive_control(
			'picker_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-picker-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'picker_padding',
			array(
				'label'      => esc_html__( 'Picker Padding', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-picker-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'picker_label_typography',
				'label'    => esc_html__( 'Label Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-picker__label',
			)
		);

		$this->add_control(
			'picker_label_color',
			array(
				'label'     => esc_html__( 'Label Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-picker-label-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'picker_dropdown_bg',
			array(
				'label'     => esc_html__( 'Dropdown Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-picker-dropdown-bg: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'picker_dropdown_typography',
				'label'    => esc_html__( 'Dropdown Typography', 'kdna-tables' ),
				'selector' => '{{WRAPPER}} .kdna-picker__select',
			)
		);

		$this->add_control(
			'picker_dropdown_color',
			array(
				'label'     => esc_html__( 'Dropdown Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-picker-dropdown-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'picker_dropdown_border',
				'selector' => '{{WRAPPER}} .kdna-picker__select',
			)
		);

		$this->add_control(
			'picker_chip_bg',
			array(
				'label'     => esc_html__( 'Chip Background', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-picker-chip-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'picker_chip_color',
			array(
				'label'     => esc_html__( 'Chip Text Colour', 'kdna-tables' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--kdna-picker-chip-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'picker_chip_radius',
			array(
				'label'      => esc_html__( 'Chip Border Radius', 'kdna-tables' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}}' => '--kdna-picker-chip-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/*
	 * Comparison render helpers. Public where the template files need to
	 * call them via $this->method().
	 */

	public function kdna_render_comparison_value( $feature_row, $slot, $settings ) {
		$indicator_key = 'cell_' . $slot . '_indicator';
		$indicator     = isset( $feature_row[ $indicator_key ] ) ? $feature_row[ $indicator_key ] : 'available';

		if ( 'available' === $indicator ) {
			return $this->kdna_render_available_indicator( $settings );
		}

		if ( 'unavailable' === $indicator ) {
			return $this->kdna_render_unavailable_indicator( $settings );
		}

		if ( 'custom' === $indicator ) {
			$arrangement = $feature_row[ 'cell_' . $slot . '_arrangement' ] ?? 'icon-text';
			$cell_type   = $feature_row[ 'cell_' . $slot . '_custom_type' ] ?? 'text';

			// Widget-level override: when set, swap icon/text order globally
			// for every mixed cell. Only applies to two-piece icon+text mixes
			// to avoid mangling three-piece arrangements that include image.
			$position_override = isset( $settings['cmp_cell_icon_position'] ) ? (string) $settings['cmp_cell_icon_position'] : 'inherit';
			if ( 'mixed' === $cell_type && in_array( $position_override, array( 'before', 'after' ), true ) ) {
				if ( 'icon-text' === $arrangement || 'text-icon' === $arrangement ) {
					$arrangement = ( 'before' === $position_override ) ? 'icon-text' : 'text-icon';
				}
			}

			$normalized = array(
				'cell_type'        => $cell_type,
				'cell_text'        => $feature_row[ 'cell_' . $slot . '_text' ] ?? '',
				'cell_icon'        => $feature_row[ 'cell_' . $slot . '_icon' ] ?? array(),
				'cell_image'       => $feature_row[ 'cell_' . $slot . '_image' ] ?? array(),
				'cell_image_size'  => $feature_row[ 'cell_' . $slot . '_image_size' ] ?? 'medium',
				'cell_arrangement' => $arrangement,
			);
			return $this->kdna_render_cell_inner( $normalized );
		}

		return '';
	}

	public function kdna_render_available_indicator( $settings ) {
		$icon = isset( $settings['available_icon'] ) ? $settings['available_icon'] : null;
		if ( empty( $icon ) || ( empty( $icon['value'] ) && empty( $icon['library'] ) ) ) {
			return '';
		}

		ob_start();
		echo '<span class="kdna-comparison__indicator kdna-comparison__indicator--available">';
		\Elementor\Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
		echo '<span class="kdna-table__sr-only">' . esc_html__( 'Available', 'kdna-tables' ) . '</span>';
		echo '</span>';
		return ob_get_clean();
	}

	public function kdna_render_unavailable_indicator( $settings ) {
		$mode = isset( $settings['unavailable_mode'] ) ? $settings['unavailable_mode'] : 'icon';

		if ( 'hidden' === $mode ) {
			return '<span class="kdna-table__sr-only">' . esc_html__( 'Not available', 'kdna-tables' ) . '</span>';
		}

		if ( 'icon' === $mode ) {
			$icon       = isset( $settings['unavailable_icon'] ) ? $settings['unavailable_icon'] : null;
			$icon_empty = empty( $icon ) || ( empty( $icon['value'] ) && empty( $icon['library'] ) );

			ob_start();
			echo '<span class="kdna-comparison__indicator kdna-comparison__indicator--unavailable">';

			if ( $icon_empty ) {
				// No icon picked. Try the plugin-bundled default SVG first
				// (assets/icons/cross.svg) so the visual default is the KDNA
				// glyph. Fall back to fas fa-minus when the file is missing
				// so behaviour stays safe between deploys.
				$bundled = self::get_bundled_default_unavailable_svg();
				if ( '' !== $bundled ) {
					echo $bundled;
				} else {
					\Elementor\Icons_Manager::render_icon(
						array( 'value' => 'fas fa-minus', 'library' => 'fa-solid' ),
						array( 'aria-hidden' => 'true' )
					);
				}
			} else {
				\Elementor\Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
			}

			echo '<span class="kdna-table__sr-only">' . esc_html__( 'Not available', 'kdna-tables' ) . '</span>';
			echo '</span>';
			return ob_get_clean();
		}

		if ( 'text' === $mode ) {
			$text = isset( $settings['unavailable_text'] ) ? (string) $settings['unavailable_text'] : '-';
			return '<span class="kdna-comparison__indicator kdna-comparison__indicator--unavailable kdna-comparison__indicator--text" aria-label="' . esc_attr__( 'Not available', 'kdna-tables' ) . '">'
				. esc_html( $text )
				. '</span>';
		}

		return '';
	}

	/**
	 * Load the plugin-bundled default Unavailable SVG and inline it. The
	 * file lives at assets/cross.svg and is expected to use
	 * fill="currentColor" so the Style > Unavailable Indicator > Colour
	 * cascades into it. Returns an empty string if the file is missing,
	 * so callers can fall back to a Font Awesome glyph.
	 *
	 * Cached statically per request, and only sanitised lightly with
	 * wp_kses so embedded <script> or external xlink:href refs cannot
	 * leak in if someone replaces the bundled file.
	 */
	public static function get_bundled_default_unavailable_svg() {
		static $cached = null;
		if ( null !== $cached ) {
			return $cached;
		}
		$path = KDNA_TABLES_PATH . 'assets/cross.svg';
		if ( ! file_exists( $path ) || ! is_readable( $path ) ) {
			$cached = '';
			return $cached;
		}
		$raw = file_get_contents( $path );
		if ( false === $raw || '' === trim( $raw ) ) {
			$cached = '';
			return $cached;
		}
		$allowed = array(
			'svg'      => array(
				'xmlns'       => true,
				'viewbox'     => true,
				'fill'        => true,
				'stroke'      => true,
				'aria-hidden' => true,
				'role'        => true,
				'focusable'   => true,
				'class'       => true,
				'width'       => true,
				'height'      => true,
				'preserveaspectratio' => true,
			),
			'path'     => array( 'd' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'fill-rule' => true, 'clip-rule' => true, 'opacity' => true ),
			'g'        => array( 'fill' => true, 'stroke' => true, 'opacity' => true, 'transform' => true ),
			'rect'     => array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true, 'fill' => true, 'stroke' => true ),
			'circle'   => array( 'cx' => true, 'cy' => true, 'r' => true, 'fill' => true, 'stroke' => true ),
			'line'     => array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true ),
			'polyline' => array( 'points' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true ),
			'polygon'  => array( 'points' => true, 'fill' => true, 'stroke' => true ),
			'title'    => array(),
			'desc'     => array(),
		);
		$svg = wp_kses( $raw, $allowed );
		// Drop any width / height attribute on the root <svg> so the CSS
		// shape size controls the rendered footprint, not whatever the
		// designer baked into the file.
		$svg = preg_replace( '/<svg([^>]*)\s(width|height)="[^"]*"/i', '<svg$1', $svg );
		// Tag the svg with the same e-font-icon-svg-style class set the
		// available indicator uses so existing CSS (width:1em; height:1em)
		// applies without a special case.
		if ( false === stripos( $svg, 'class="' ) ) {
			$svg = preg_replace( '/<svg\b/i', '<svg class="kdna-comparison__indicator-svg" aria-hidden="true"', $svg, 1 );
		} else {
			$svg = preg_replace( '/<svg([^>]*\bclass=")([^"]*)"/i', '<svg$1$2 kdna-comparison__indicator-svg"', $svg, 1 );
		}
		$cached = $svg;
		return $cached;
	}

	/*
	 * Cell render helpers. Public so the template files can call them via
	 * $this->method() while included from the render method.
	 */

	public function kdna_cell_modifier_class( $cell ) {
		$type = isset( $cell['cell_type'] ) ? $cell['cell_type'] : '';
		if ( '' === $type ) {
			return '';
		}
		return 'kdna-table__cell--' . sanitize_html_class( $type );
	}

	public function kdna_resolve_cell_alignment( $cell, $column ) {
		$override = isset( $cell['cell_alignment_override'] ) ? $cell['cell_alignment_override'] : 'inherit';
		if ( in_array( $override, array( 'left', 'center', 'right' ), true ) ) {
			return $override;
		}
		$col_align = isset( $column['column_alignment'] ) ? $column['column_alignment'] : 'left';
		if ( ! in_array( $col_align, array( 'left', 'center', 'right' ), true ) ) {
			$col_align = 'left';
		}
		return $col_align;
	}

	public function kdna_render_cell_inner( $cell ) {
		if ( empty( $cell ) || empty( $cell['cell_type'] ) ) {
			return '';
		}

		$type   = $cell['cell_type'];
		$pieces = array();

		if ( 'text' === $type ) {
			$pieces['text'] = $this->kdna_render_cell_text_piece( $cell );
		} elseif ( 'icon' === $type ) {
			$pieces['icon'] = $this->kdna_render_cell_icon_piece( $cell );
		} elseif ( 'image' === $type ) {
			$pieces['image'] = $this->kdna_render_cell_image_piece( $cell );
		} elseif ( 'mixed' === $type ) {
			$arrangement = isset( $cell['cell_arrangement'] ) ? $cell['cell_arrangement'] : 'icon-text';
			foreach ( $this->kdna_arrangement_order( $arrangement ) as $piece ) {
				if ( 'text' === $piece ) {
					$pieces['text'] = $this->kdna_render_cell_text_piece( $cell );
				} elseif ( 'icon' === $piece ) {
					$pieces['icon'] = $this->kdna_render_cell_icon_piece( $cell );
				} elseif ( 'image' === $piece ) {
					$pieces['image'] = $this->kdna_render_cell_image_piece( $cell );
				}
			}
		}

		return implode( '', array_filter( $pieces ) );
	}

	protected function kdna_arrangement_order( $arrangement ) {
		switch ( $arrangement ) {
			case 'text-icon':
				return array( 'text', 'icon' );
			case 'icon-text-image':
				return array( 'icon', 'text', 'image' );
			case 'image-text-icon':
				return array( 'image', 'text', 'icon' );
			case 'icon-text':
			default:
				return array( 'icon', 'text' );
		}
	}

	protected function kdna_render_cell_text_piece( $cell ) {
		$text = isset( $cell['cell_text'] ) ? $cell['cell_text'] : '';
		if ( '' === $text ) {
			return '';
		}
		return '<span class="kdna-table__cell-text">' . wp_kses_post( $text ) . '</span>';
	}

	protected function kdna_render_cell_icon_piece( $cell ) {
		if ( empty( $cell['cell_icon'] ) ) {
			return '';
		}
		$icon = $cell['cell_icon'];
		if ( empty( $icon['value'] ) && empty( $icon['library'] ) ) {
			return '';
		}
		ob_start();
		echo '<span class="kdna-table__cell-icon">';
		\Elementor\Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
		echo '</span>';
		return ob_get_clean();
	}

	protected function kdna_render_cell_image_piece( $cell ) {
		if ( empty( $cell['cell_image']['id'] ) && empty( $cell['cell_image']['url'] ) ) {
			return '';
		}
		$image_html = \Elementor\Group_Control_Image_Size::get_attachment_image_html( $cell, 'cell_image_size', 'cell_image' );
		if ( '' === $image_html ) {
			return '';
		}
		return '<span class="kdna-table__cell-image">' . $image_html . '</span>';
	}

	protected function render() {
		// Wrap the settings read in try/catch for the same reason as in
		// get_style_depends(): Elementor sanitize_settings() fatals on
		// null. Legacy v1.x instances that haven't migrated yet may have
		// null stored settings, and we want the page to keep rendering
		// (and reach the migration notice in the editor) rather than 500.
		try {
			$widget_settings = $this->get_settings_for_display();
		} catch ( \Throwable $e ) {
			$this->render_wrapped_placeholder(
				'',
				esc_html__( 'This widget has unmigrated v1.x data. Open it in the Elementor editor and click Migrate.', 'kdna-tables' )
			);
			return;
		}
		if ( ! is_array( $widget_settings ) ) {
			$widget_settings = array();
		}

		$table_id = isset( $widget_settings['selected_table_id'] ) ? (int) $widget_settings['selected_table_id'] : 0;

		// No table picked yet, bail to the placeholder.
		if ( $table_id <= 0 ) {
			$this->render_wrapped_placeholder( '', esc_html__( 'Select a table from the dropdown.', 'kdna-tables' ) );
			return;
		}

		$settings = KDNA_Tables_Data::get_settings_for_render( $table_id, $widget_settings );
		if ( empty( $settings ) ) {
			$this->render_wrapped_placeholder( '', esc_html__( 'The selected table no longer exists.', 'kdna-tables' ) );
			return;
		}

		$table_type = isset( $settings['table_type'] ) ? (string) $settings['table_type'] : '';
		if ( 'general' !== $table_type && 'comparison' !== $table_type ) {
			$this->render_wrapped_placeholder( '', esc_html__( 'The selected table is missing a type.', 'kdna-tables' ) );
			return;
		}

		$wrapper_classes = array(
			'kdna-table__wrapper',
			'kdna-table__wrapper--' . sanitize_html_class( $table_type ),
		);

		$responsive_mode       = isset( $widget_settings['responsive_mode'] ) ? $widget_settings['responsive_mode'] : 'card_stack';
		$responsive_breakpoint = isset( $widget_settings['responsive_breakpoint'] ) ? $widget_settings['responsive_breakpoint'] : 'mobile';
		$pivot_label_position  = isset( $widget_settings['pivot_label_position'] ) ? $widget_settings['pivot_label_position'] : 'above';

		$picker_config = array();
		if ( 'comparison' === $table_type && 'column_picker' === $responsive_mode ) {
			$items_for_picker = array();
			$items_raw        = isset( $settings['items'] ) && is_array( $settings['items'] ) ? array_values( $settings['items'] ) : array();
			$items_raw        = array_slice( $items_raw, 0, 6 );
			foreach ( $items_raw as $i => $item ) {
				$items_for_picker[] = array(
					'slot'  => $i + 1,
					'label' => isset( $item['item_label'] ) ? (string) $item['item_label'] : sprintf( esc_html__( 'Item %d', 'kdna-tables' ), $i + 1 ),
				);
			}
			$defaults      = isset( $widget_settings['picker_default_items'] ) && is_array( $widget_settings['picker_default_items'] ) ? $widget_settings['picker_default_items'] : array();
			$picker_config = array(
				'items'     => $items_for_picker,
				'defaults'  => array_values( array_map( 'intval', $defaults ) ),
				'maxSelect' => isset( $widget_settings['picker_max_select'] ) ? (int) $widget_settings['picker_max_select'] : 2,
				'label'     => isset( $widget_settings['picker_label_text'] ) ? (string) $widget_settings['picker_label_text'] : esc_html__( 'Compare', 'kdna-tables' ),
			);
		}

		$sticky_first_column = ! empty( $widget_settings['sticky_first_column'] ) && 'yes' === $widget_settings['sticky_first_column'];

		$wrapper_attrs = array(
			'class'                      => implode( ' ', $wrapper_classes ),
			'data-table-type'            => $table_type,
			'data-responsive-mode'       => $responsive_mode,
			'data-responsive-breakpoint' => $responsive_breakpoint,
			'data-pivot-label-position'  => $pivot_label_position,
			'data-sticky-first-column'   => $sticky_first_column ? 'yes' : 'no',
			'data-table-id'              => (string) $table_id,
		);
		if ( ! empty( $picker_config ) ) {
			$wrapper_attrs['data-picker-config'] = wp_json_encode( $picker_config );
		}

		// Expose the sticky flag to render templates so they can wrap the
		// table in the horizontal scroll container.
		$settings['__sticky_first_column'] = $sticky_first_column;

		$attr_string = '';
		foreach ( $wrapper_attrs as $name => $value ) {
			$attr_string .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( $value ) );
		}

		?>
		<div<?php echo $attr_string; ?>>
			<?php
			if ( 'general' === $table_type ) {
				include KDNA_TABLES_PATH . 'templates/render-general.php';
			} elseif ( 'comparison' === $table_type ) {
				include KDNA_TABLES_PATH . 'templates/render-comparison.php';
			}
			?>
		</div>
		<?php
	}

	/*
	 * The shipped render-placeholder.php template carries its own hardcoded
	 * message from v1.x, so we cannot use it for the new context-specific
	 * messages without modifying the template (the brief locks template
	 * files). Emit the same placeholder markup with a custom message
	 * inline.
	 */
	private function render_wrapped_placeholder( $table_type, $message ) {
		$wrapper_classes = array( 'kdna-table__wrapper', 'kdna-table__wrapper--placeholder' );
		if ( '' !== $table_type ) {
			$wrapper_classes[] = 'kdna-table__wrapper--' . sanitize_html_class( $table_type );
		}
		printf(
			'<div class="%1$s" data-table-type="%2$s"><div class="kdna-table__placeholder" role="status"><span class="kdna-table__placeholder-message">%3$s</span></div></div>',
			esc_attr( implode( ' ', $wrapper_classes ) ),
			esc_attr( $table_type ),
			esc_html( $message )
		);
	}
}
